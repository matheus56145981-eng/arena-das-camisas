import Image from 'next/image';
import { useState } from 'react';
import { ShoppingCart, Filter } from 'lucide-react';

export default function Home() {
  const [filtro, setFiltro] = useState('Todos');

  const produtos = [
    { id: 1, nome: 'Camisa Brasil 2024', preco: 'R$199,90', tipo: 'Seleções', imagem: '/camisa-brasil.jpg' },
    { id: 2, nome: 'Camisa Real Madrid 2024', preco: 'R$249,90', tipo: 'Clubes', imagem: '/camisa-real.jpg' },
    { id: 3, nome: 'Camisa PSG 2024', preco: 'R$239,90', tipo: 'Clubes', imagem: '/camisa-psg.jpg' },
    { id: 4, nome: 'Camisa Argentina 2024', preco: 'R$219,90', tipo: 'Seleções', imagem: '/camisa-argentina.jpg' }
  ];

  const produtosFiltrados = filtro === 'Todos' ? produtos : produtos.filter(p => p.tipo === filtro);

  return (
    <main className='min-h-screen bg-gray-50 text-gray-900 font-sans'>
      <header className='flex items-center justify-between p-4 shadow-md bg-white'>
        <div className='flex items-center gap-3'>
          <Image src='/ArenaDasCamisas.jfif' alt='Logo Arena das Camisas' width={60} height={60} className='rounded-full' />
          <h1 className='text-2xl font-bold text-gray-800'>Arena das Camisas</h1>
        </div>
        <button className='flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md'>
          <ShoppingCart size={18}/> Carrinho
        </button>
      </header>

      <section className='text-center py-16 bg-gradient-to-b from-blue-700 to-blue-500 text-white'>
        <h2 className='text-4xl font-bold mb-3'>Vista sua paixão pelo futebol</h2>
        <p className='text-lg opacity-90 mb-6'>Camisas oficiais e retrôs para torcedores e jogadores</p>
        <button className='bg-white text-blue-700 font-semibold px-6 py-3 rounded-md hover:bg-gray-100'>Explorar Camisas</button>
      </section>

      <section className='max-w-6xl mx-auto p-6 flex flex-col sm:flex-row items-center justify-between gap-4'>
        <div className='flex items-center gap-2 text-gray-700'>
          <Filter size={18} />
          <span className='font-medium'>Filtrar por:</span>
        </div>
        <div className='flex gap-3'>
          {['Todos', 'Clubes', 'Seleções'].map(opcao => (
            <button
              key={opcao}
              onClick={() => setFiltro(opcao)}
              className={`px-4 py-2 rounded-md border ${filtro === opcao ? 'bg-blue-600 text-white' : 'bg-white text-gray-800 hover:bg-gray-100'}`}
            >
              {opcao}
            </button>
          ))}
        </div>
      </section>

      <section className='max-w-6xl mx-auto p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6'>
        {produtosFiltrados.map((p) => (
          <div key={p.id} className='shadow-md hover:shadow-lg transition border-none bg-white rounded-xl p-4 text-center'>
            <Image src={p.imagem} alt={p.nome} width={300} height={300} className='mx-auto rounded-xl' />
            <h3 className='text-lg font-semibold mt-3'>{p.nome}</h3>
            <p className='text-blue-700 font-bold mt-1'>{p.preco}</p>
            <button className='mt-3 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 w-full rounded-md'>Adicionar ao carrinho</button>
          </div>
        ))}
      </section>

      <footer className='text-center py-6 mt-10 border-t text-sm text-gray-600'>
        © {new Date().getFullYear()} Arena das Camisas — Todos os direitos reservados.
      </footer>
    </main>
  );
}
